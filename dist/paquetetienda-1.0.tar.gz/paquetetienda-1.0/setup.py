from setuptools import setup

setup(
    name="paquetetienda",
    version="1.0",
    description="permite crear clientes y productos",
    author="Miller Ladino",
    url="https://github.com/millertsu1",
    packages=["clases"]
)
